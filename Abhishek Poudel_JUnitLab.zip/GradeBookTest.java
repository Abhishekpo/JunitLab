import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {

	GradeBook a1, a2;
	
	@BeforeEach
	void setUp() throws Exception {
	a1 =new GradeBook(5);
	a1.addScore(8.2);
	a1.addScore(6.5);
	
    a2= new GradeBook(5);
	a2.addScore(12.2);
	a2.addScore(7.5);
	}
	
	@AfterEach
	void tearDown() throws Exception {
	a1 = null;
	a2= null;
	
	}

	@Test
	void testAddScore() {
		assertTrue(a1.toString().equals("8.2 6.5 "));
		assertTrue(a2.toString().equals("12.2 7.5 "));
	}

	@Test
	void testSum() {
		assertEquals(14.7, a1.sum(), .0001);
		assertEquals(19.7, a2.sum(), .0001);
	}

	@Test
	void testMinimum() {
		assertEquals(6.5, a1.minimum(), .001);
		assertEquals(7.5, a2.minimum(), .001);
	}

	@Test
	void testFinalScore() {
		assertEquals(8.2, a1.finalScore(), .001);
		assertEquals(12.2, a2.finalScore(), .001);
	}

	@Test
	void testGetScoreSize() {
		assertEquals(2, a1.getScoreSize());
		assertEquals(2, a2.getScoreSize());
	}

}
